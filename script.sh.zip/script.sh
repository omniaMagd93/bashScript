#!/bin/bash

 
pause(){
  read -p "Press [Enter] key to continue..." fackEnterKey
}

echo "Create DataBase"
read -p "Enter Your DataBase Name" db
mkdir $db
read -p "Enter Table Name: " table
echo > $db/$table.csv
echo > $db/$table"_config".csv

sed -i 1i"Col,DT,Pk,unique,Def,Null" $db/$table"_config".csv

read -p "Enter Number Of columns: " col
    
    counterConf=1
    counter2=2
    counter=1
    while [ $counter -le $col ]

        do
            read -p "Enter Name of the $counter column: " colName
            arr[$counter]=$colName
	    config[$counterConf]=$colName
            ((counterConf++))
            
#data type
	    clear
            echo "Choose Your Data Type"
	    echo "1-Integer" 
	    echo "2-VarChar"
	    
	    read -p "What is Your DataType:" config[$counterConf]
	    ((counterConf++))
#primary key
            clear
	    read -p "Is Primary Key(y/n)" config[$counterConf]
            ((counterConf++))
#unique
            clear
	    read -p "Is Unique (y/n)" config[$counterConf]
	    ((counterConf++))
#Default
            clear
            read -p "Has Default Value (y/n)" default
            if [ $default == 'n' ]
		then
			config[$counterConf]="Null"
	    else
	    	read -p "What is Your defualt value" config[$counterConf]
	    fi
            ((counterConf++))
#null
	    clear
            read -p "Is Null (y/n)" config[$counterConf]

            ((counterConf++))
config1=$( echo ${config[@]} | sed 's/ /,/g' )
sed -i ${counter2}i"${config1[@]}" $db/$table"_config".csv
config=()
            ((counter2++))
            ((counter++))
        done
            
echo ${arr[@]} 
arr1=$( echo ${arr[@]} | sed 's/ /,/g' )
echo ${arr1[@]}

sed -i 1i"${arr1[@]}" $db/$table.csv
